from django import forms
from .models import Docente, Material, Usuario, Rol, Prestamo

class DocenteForm(forms.ModelForm):
    class Meta:
        model = Docente
        fields = ['nombre', 'correo', 'telefono', 'estado']

class MaterialForm(forms.ModelForm):
    class Meta:
        model = Material
        fields = ['nombre', 'modelo', 'stock', 'estado']

class UsuarioForm(forms.ModelForm):
    class Meta:
        model = Usuario
        fields = ['nombre', 'correo', 'password', 'id_rol', 'estado']
        widgets = {
            'password': forms.PasswordInput(),
            
        }
id_rol = forms.ModelChoiceField(queryset=Rol.objects.all(), required=True, empty_label=None)

class PrestamoForm(forms.ModelForm):
    class Meta:
        model = Prestamo
        fields = ['docente', 'material', 'cantidad']
        widgets = {
            'cantidad': forms.NumberInput(attrs={'min': 1}),
        }