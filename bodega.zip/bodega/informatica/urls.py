from django.urls import path
from . import views

urlpatterns = [
    path('login/', views.iniciar_sesion, name='login'),
    path('logout/', views.cerrar_sesion, name='logout'),
    path('panol/', views.vista_para_panol, name='vista_para_panol'),  # Ruta para el pañol
    path('admin_dashboard/', views.vista_para_administradores, name='vista_para_administradores'),
    path('', views.inicio, name='inicio'),  # Nueva ruta para la raíz
    
    path('', views.menu_principal, name='menu_principal'),
    path('docentes/', views.listar_docentes, name='listar_docentes'),
    path('docentes/crear/', views.crear_docente, name='crear_docente'),
    path('docentes/editar/<int:pk>/', views.actualizar_docente, name='actualizar_docente'),
    path('docentes/eliminar/<int:pk>/', views.eliminar_docente, name='eliminar_docente'),

    # Material URLs
    path('materiales/', views.listar_materiales, name='listar_materiales'),
    path('materiales/crear/', views.crear_material, name='crear_material'),
    path('materiales/editar/<int:pk>/', views.actualizar_material, name='actualizar_material'),
    path('materiales/eliminar/<int:pk>/', views.eliminar_material, name='eliminar_material'),

    # Usuario URLs
    path('usuarios/', views.listar_usuarios, name='listar_usuarios'),
    path('usuarios/crear/', views.crear_usuario, name='crear_usuario'),
    path('usuarios/editar/<int:pk>/', views.actualizar_usuario, name='actualizar_usuario'),
    path('usuarios/eliminar/<int:pk>/', views.eliminar_usuario, name='eliminar_usuario'),
    path('prestamos/registrar/', views.registrar_prestamo, name='registrar_prestamo'),
    path('prestamos/', views.listar_prestamos, name='listar_prestamos'),
]
