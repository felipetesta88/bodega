from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.hashers import check_password, make_password
from .models import Docente, Material, Usuario, Rol, Prestamo
from .forms import DocenteForm, MaterialForm, UsuarioForm, PrestamoForm
from django.core.paginator import Paginator

# **Autenticación**

def raiz(request):
    return redirect('login')  # Redirige directamente al login

def inicio(request):
    return render(request, 'inicio.html')

def iniciar_sesion(request):
    if request.method == 'POST':
        correo = request.POST['correo']
        password = request.POST['password']

        try:
            usuario = Usuario.objects.get(correo=correo)
        except Usuario.DoesNotExist:
            return render(request, 'login.html', {'error': 'Correo o contraseña incorrectos'})

        if check_password(password, usuario.password) and usuario.estado:
            # Crear sesión personalizada
            request.session['usuario_id'] = usuario.id
            request.session['usuario_rol'] = usuario.id_rol.nombre

            # Redirigir según el rol
            if usuario.id_rol.nombre == "Administrador":
                return redirect('vista_para_administradores')
            elif usuario.id_rol.nombre == "Pañol":
                return redirect('vista_para_panol')
            else:
                return redirect('inicio')  # Redirige al inicio
        else:
            return render(request, 'login.html', {'error': 'Correo o contraseña incorrectos'})

    return render(request, 'login.html')

def cerrar_sesion(request):
    # Limpiar la sesión
    request.session.flush()
    return redirect('login')

# **Restricciones por Rol**

def obtener_usuario_desde_sesion(request):
    usuario_id = request.session.get('usuario_id')
    if not usuario_id:
        return None
    return get_object_or_404(Usuario, id=usuario_id)

def vista_para_administradores(request):
    usuario = obtener_usuario_desde_sesion(request)
    if not usuario or usuario.id_rol.nombre != "Administrador":
        return redirect('login')  # Redirige al login si no es administrador

    return render(request, 'admin_dashboard.html')

def vista_para_panol(request):
    usuario = obtener_usuario_desde_sesion(request)
    if not usuario or usuario.id_rol.nombre != "Pañol":
        return redirect('login')  # Redirige al login si no es pañol
    # Obtener todos los préstamos
    prestamos = Prestamo.objects.all()
    

    return render(request, 'panol_dashboard.html',{'prestamos': prestamos})

# **Docente CRUD**

def listar_docentes(request):
    docentes = Docente.objects.all()
    return render(request, 'docente_listar.html', {'docentes': docentes})

def crear_docente(request):
    if request.method == 'POST':
        form = DocenteForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('listar_docentes')
    else:
        form = DocenteForm()
    return render(request, 'form.html', {'form': form, 'title': 'Crear Docente', 'cancel_url': 'listar_docentes'})

def actualizar_docente(request, pk):
    docente = get_object_or_404(Docente, pk=pk)
    if request.method == 'POST':
        form = DocenteForm(request.POST, instance=docente)
        if form.is_valid():
            form.save()
            return redirect('listar_docentes')
    else:
        form = DocenteForm(instance=docente)
    return render(request, 'form.html', {'form': form, 'title': 'Actualizar Docente', 'cancel_url': 'listar_docentes'})

def eliminar_docente(request, pk):
    docente = get_object_or_404(Docente, pk=pk)
    docente.delete()
    return redirect('listar_docentes')

# **Material CRUD**

def listar_materiales(request):
    materiales = Material.objects.all()
    return render(request, 'material_listar.html', {'materiales': materiales})

def crear_material(request):
    if request.method == 'POST':
        form = MaterialForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('listar_materiales')
    else:
        form = MaterialForm()
    return render(request, 'form.html', {'form': form, 'title': 'Crear Material', 'cancel_url': 'listar_materiales'})

def actualizar_material(request, pk):
    material = get_object_or_404(Material, pk=pk)
    if request.method == 'POST':
        form = MaterialForm(request.POST, instance=material)
        if form.is_valid():
            form.save()
            return redirect('listar_materiales')
    else:
        form = MaterialForm(instance=material)
    return render(request, 'form.html', {'form': form, 'title': 'Actualizar Material', 'cancel_url': 'listar_materiales'})

def eliminar_material(request, pk):
    material = get_object_or_404(Material, pk=pk)
    material.delete()
    return redirect('listar_materiales')

# **Usuario CRUD**

def listar_usuarios(request):
    usuarios = Usuario.objects.all()
    return render(request, 'usuario_listar.html', {'usuarios': usuarios})

def crear_usuario(request):
    if request.method == 'POST':
        form = UsuarioForm(request.POST)
        if form.is_valid():
            usuario = form.save(commit=False)
            usuario.password = make_password(usuario.password)
            usuario.save()
            return redirect('listar_usuarios')
    else:
        form = UsuarioForm()
    return render(request, 'form.html', {'form': form, 'title': 'Crear Usuario', 'cancel_url': 'listar_usuarios'})

def actualizar_usuario(request, pk):
    usuario = get_object_or_404(Usuario, pk=pk)
    if request.method == 'POST':
        form = UsuarioForm(request.POST, instance=usuario)
        if form.is_valid():
            usuario = form.save(commit=False)
            if form.cleaned_data['password']:
                usuario.password = make_password(usuario.password)
            usuario.save()
            return redirect('listar_usuarios')
    else:
        form = UsuarioForm(instance=usuario)
    return render(request, 'form.html', {'form': form, 'title': 'Actualizar Usuario', 'cancel_url': 'listar_usuarios'})

def eliminar_usuario(request, pk):
    usuario = get_object_or_404(Usuario, pk=pk)
    usuario.delete()
    return redirect('listar_usuarios')

def registrar_prestamo(request):
    usuario = obtener_usuario_desde_sesion(request)
    if not usuario or usuario.id_rol.nombre != "Pañol":
        return redirect('login')  # Redirige si no es un usuario autorizado

    if request.method == 'POST':
        form = PrestamoForm(request.POST)
        if form.is_valid():
            prestamo = form.save(commit=False)
            material = prestamo.material

            # Verificar si hay suficiente stock
            if prestamo.cantidad > material.stock:
                return render(request, 'registrar_prestamo.html', {
                    'form': form,
                    'error': 'No hay suficiente stock disponible'
                })

            # Reducir el stock y guardar el préstamo
            material.stock -= prestamo.cantidad
            material.save()
            prestamo.save()
            return redirect('listar_prestamos')  # Redirige a una página para listar préstamos
    else:
        form = PrestamoForm()

    return render(request, 'registrar_prestamo.html', {'form': form})

def listar_prestamos(request):
    usuario = obtener_usuario_desde_sesion(request)
    if not usuario or usuario.id_rol.nombre != "Pañol":
        return redirect('login')  # Redirige si no es un usuario autorizado
    prestamos_list = Prestamo.objects.all()
    paginator = Paginator(prestamos_list, 10)  # Muestra 10 préstamos por página
    page_number = request.GET.get('page')
    prestamos = paginator.get_page(page_number)
    

    

    
    return render(request, 'listar_prestamos.html', {'prestamos': prestamos})




